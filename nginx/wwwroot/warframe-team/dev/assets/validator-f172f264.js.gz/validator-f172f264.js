import{b9 as i}from"./index-69a426b7.js";const n=o=>["",...i].includes(o);export{n as i};
